package de.azizothman.util;


public class ImageUtil {

	public ImageUtil() {
	}

	/**
	 *  Convert the given image to round.
	 * 
	 *  @param image the image will be converted to round
	 *  @return rounded image
	 */
	public static com.codename1.ui.Image roundImage(com.codename1.ui.Image image) {
	}
}
